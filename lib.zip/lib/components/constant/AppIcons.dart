
const String _iconPath = 'assets/icon/';

class AppIcons{
  static const String backButton = '${_iconPath}back.png';
  static const String male = '${_iconPath}male.png';
  static const String female = '${_iconPath}female.png';
  static const String user = '${_iconPath}user.png';
  static const String remove = '${_iconPath}trash.png';
}